--
-- A Mysql Backup System 
--
-- Export created: 2018/01/19 on 01:04


--
-- Database : baza
--
-- --------------------------------------------------
-- ---------------------------------------------------
SET AUTOCOMMIT = 0 ;
SET FOREIGN_KEY_CHECKS=0 ;
--
-- Tabel structure for table `categories_list`
--
DROP TABLE  IF EXISTS `categories_list`;
CREATE TABLE `categories_list` (
  `category_id` int(10) NOT NULL AUTO_INCREMENT,
  `category_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category_active` int(10) NOT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=MyISAM AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `categories_list`  VALUES ( "1","Notebooks","1");
INSERT INTO `categories_list`  VALUES ( "2","Phones","1");
INSERT INTO `categories_list`  VALUES ( "3","Plastic Bottles","0");
INSERT INTO `categories_list`  VALUES ( "4","Televiosinos","1");
INSERT INTO `categories_list`  VALUES ( "5","Bulbs","1");
INSERT INTO `categories_list`  VALUES ( "6","Displays","1");
INSERT INTO `categories_list`  VALUES ( "7","Tablet","1");
INSERT INTO `categories_list`  VALUES ( "8","Graphic Card GPU","1");
INSERT INTO `categories_list`  VALUES ( "21","Backpack","1");
INSERT INTO `categories_list`  VALUES ( "18","Smart Watch","1");
INSERT INTO `categories_list`  VALUES ( "19","Mouse","1");
INSERT INTO `categories_list`  VALUES ( "20","Ink Jet Printers","1");
INSERT INTO `categories_list`  VALUES ( "22","4K & UltraHD TVs","1");
INSERT INTO `categories_list`  VALUES ( "25","Desktop PC","1");


--
-- Tabel structure for table `company_info`
--
DROP TABLE  IF EXISTS `company_info`;
CREATE TABLE `company_info` (
  `company_logo` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `company_name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `company_address` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `company_email` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `company_phone` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`company_name`),
  UNIQUE KEY `company_name` (`company_name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `company_info`  VALUES ( "logo.png","SCMS d.o.o","Zmaja od Bosne 1, Sarajevo, BiH","venanosmic24@gmail.com","+387 61 456 061");


--
-- Tabel structure for table `customers_list`
--
DROP TABLE  IF EXISTS `customers_list`;
CREATE TABLE `customers_list` (
  `customer_id` int(10) NOT NULL AUTO_INCREMENT,
  `customer_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `customer_address` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `customer_phone` char(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `customer_email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`customer_id`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `customers_list`  VALUES ( "2","ABITEC d.o.o.","Husein Kapetana Grada�?evi?a, Jelah 74264, Tesanj","+387 (0) 32 667 300","abitec@bih.net.ba");
INSERT INTO `customers_list`  VALUES ( "8","Mlekara Fass d.o.o.","Prijepoljska bb 36 310 Sjenica, Republika Srbija","+381 (0) 20 740 030","mlekarafass@mts.rs");
INSERT INTO `customers_list`  VALUES ( "13","IMTEC d.o.o.","Vrbanja 1, SCC","033 944 300","info@imtec.ba");
INSERT INTO `customers_list`  VALUES ( "6","Zlatarna Osmi?","Titova 61, Te�anj 74260","+387 61 793 458","kontakt@osmic.com.ba");


--
-- Tabel structure for table `discount_list`
--
DROP TABLE  IF EXISTS `discount_list`;
CREATE TABLE `discount_list` (
  `discount_id` int(10) NOT NULL AUTO_INCREMENT,
  `discount_name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `discount_amount` int(10) NOT NULL,
  PRIMARY KEY (`discount_id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `discount_list`  VALUES ( "8","Master Card User 10%","10");
INSERT INTO `discount_list`  VALUES ( "7","New Year Discount 25%","25");
INSERT INTO `discount_list`  VALUES ( "9","Last Minute Chance 50%","50");


--
-- Tabel structure for table `products_list`
--
DROP TABLE  IF EXISTS `products_list`;
CREATE TABLE `products_list` (
  `product_id` int(10) NOT NULL AUTO_INCREMENT,
  `product_category` int(10) NOT NULL,
  `product_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_model` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `product_details` text COLLATE utf8mb4_unicode_ci,
  `product_quantity` int(10) NOT NULL DEFAULT '0',
  `product_photo` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`product_id`)
) ENGINE=MyISAM AUTO_INCREMENT=74 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `products_list`  VALUES ( "22","1","Acer","Aspire ES1","","10","Acer-Aspire-ES1-531-C7TQ.jpg");
INSERT INTO `products_list`  VALUES ( "21","2","Apple","iPhone X","64/256GB","200","apple-iphone-x-new-1.jpg");
INSERT INTO `products_list`  VALUES ( "20","2","Apple","iPhone 5s","16/32/64GB","10","apple-iphone-5s-ofic.jpg");
INSERT INTO `products_list`  VALUES ( "19","2","Apple","iPhone 6s","16/32/64/128GB","7","iPhone-6s-26925.jpg");
INSERT INTO `products_list`  VALUES ( "23","1","Acer","Aspire ES1-531","","4","Acer-Aspire-ES1-531-C8Z7.jpg");
INSERT INTO `products_list`  VALUES ( "24","1","Acer","VX5","","1","Acer-VX5.jpg");
INSERT INTO `products_list`  VALUES ( "27","1","ASUS","ROG GL552VX","","10","ASUS-ROG-GL552VX.jpg");
INSERT INTO `products_list`  VALUES ( "29","7","Samsung","Tab A6","","10","Samsung-Galaxy-Tab-A6.jpg");
INSERT INTO `products_list`  VALUES ( "30","7","ASUS","ZenPad 10","","230","ASUS-ZenPad-10.jpg");
INSERT INTO `products_list`  VALUES ( "31","7","Samsung","Galaxy Tab E","","1","SAMSUNG-Galaxy-Tab-E.jpg");
INSERT INTO `products_list`  VALUES ( "32","8","ASUS","Radeon R5 230 2GB","","7","R5-230-2GB.jpg");
INSERT INTO `products_list`  VALUES ( "33","8","ASUS","Radeon R7 250 1GB","","5","ASUS-Radeon-R7-250.jpg");
INSERT INTO `products_list`  VALUES ( "34","8","NVIDIA","GTX1050Ti 4GB","","2","GTX-1050-ti.jpg");
INSERT INTO `products_list`  VALUES ( "40","18","Samsung","Galaxy Gear SPORT","","3","Screenshot_1.png");
INSERT INTO `products_list`  VALUES ( "41","18","Samsung","Gear Fit 2 Pro Small Black","","3","Screenshot_2.png");
INSERT INTO `products_list`  VALUES ( "42","18","Samsung","Gear S3 Classic","","3","Samsung-Gear S3 Classic-22753-5638.png");
INSERT INTO `products_list`  VALUES ( "43","19","ASUS","ROG Cerberus","","7","Screenshot_4.png");
INSERT INTO `products_list`  VALUES ( "44","19","ASUS","ROG Gladius","","7","Untitled.png");
INSERT INTO `products_list`  VALUES ( "45","19","ASUS","ROG SICA","","7","Screenshot_5.png");
INSERT INTO `products_list`  VALUES ( "46","1","Lenovo","IdeaPad 320-15 (80XH008KSC)","","1","Screenshot_6.png");
INSERT INTO `products_list`  VALUES ( "47","1","Lenovo","IP 320-15 (80XH008KSC)","","1","Screenshot_7.png");
INSERT INTO `products_list`  VALUES ( "48","1","Lenovo","Legion Y520-15 ( 80WK009USC)","","1","Screenshot_8.png");
INSERT INTO `products_list`  VALUES ( "49","20","Canon","Maxify iB4150","","2","Screenshot_9.png");
INSERT INTO `products_list`  VALUES ( "50","20","Canon","Pixma G1400 (0629C009AA)","","2","Screenshot_10.png");
INSERT INTO `products_list`  VALUES ( "51","20","Canon","Pixma ip2850","","2","Screenshot_11.png");
INSERT INTO `products_list`  VALUES ( "55","21","PORT","Design Hanoi 15,6 (105320)","up to 15,6 '' notebooks","10","PORT-Design Hanoi 15,6 (105320)-24542-9663.png");
INSERT INTO `products_list`  VALUES ( "56","21","PORT","","up to 17,3 '' notebooks","10","PORT-Courchevel-26005-22186.png");
INSERT INTO `products_list`  VALUES ( "57","21","HP","Full Featured","up to 17,3 '' notebooks","10","HP-Full Featured-25243-26168.png");
INSERT INTO `products_list`  VALUES ( "58","22","Panasonic","LED UltraHD SMART TV TX-55DS503E","55 ''","3","Panasonic-LED UltraHD SMART TV TX-55DS503E-3447-11748.png");
INSERT INTO `products_list`  VALUES ( "59","22","Philips","LED UltraHD Android TV 49PUS7101/12 Ambilight","49&quot;, 4K Ultra HD LED, rezolucija 3840 x 2160","3","Philips-za-ispravit.png");
INSERT INTO `products_list`  VALUES ( "60","22","Samsung","LED TV 49KU6172 Zakrivljeni 4K SMART (UE49KU6172UXXH)","49&quot;(125cm). Tip ekrana: E-LED. Zakrivljenost ekrana: 3000r","3","7026-7107-27712.png");
INSERT INTO `products_list`  VALUES ( "72","25","HP","490PD G3 i7","&lt;p&gt;&lt;span style=&quot;color: rgb(98, 98, 98); font-family: &amp;quot;Open Sans&amp;quot;, Arial, Tahoma, sans-serif;&quot;&gt;&lt;strong&gt;CPU:&lt;/strong&gt; Intel Core i7 6700 3.40 GHz, 8MB&lt;/span&gt;&lt;/p&gt;&lt;p&gt;&lt;span style=&quot;color: rgb(98, 98, 98); font-family: &amp;quot;Open Sans&amp;quot;, Arial, Tahoma, sans-serif;&quot;&gt;&lt;strong&gt;RAM:&lt;/strong&gt; 8 GB DDR4, 2133&lt;/span&gt;&lt;/p&gt;&lt;p&gt;&lt;span style=&quot;color: rgb(98, 98, 98); font-family: &amp;quot;Open Sans&amp;quot;, Arial, Tahoma, sans-serif;&quot;&gt;&lt;strong&gt;VGA:&lt;/strong&gt; Intel HD&lt;/span&gt;&lt;/p&gt;&lt;p&gt;&lt;span style=&quot;color: rgb(98, 98, 98); font-family: &amp;quot;Open Sans&amp;quot;, Arial, Tahoma, sans-serif;&quot;&gt;&lt;strong&gt;HDD:&lt;/strong&gt; 1 TB&lt;/span&gt;&lt;/p&gt;&lt;p&gt;&lt;span style=&quot;color: rgb(98, 98, 98); font-family: &amp;quot;Open Sans&amp;quot;, Arial, Tahoma, sans-serif;&quot;&gt;&lt;strong&gt;Optika:&lt;/strong&gt; DVD-RW&lt;/span&gt;&lt;/p&gt;&lt;p&gt;&lt;span style=&quot;color: rgb(98, 98, 98); font-family: &amp;quot;Open Sans&amp;quot;, Arial, Tahoma, sans-serif;&quot;&gt;&lt;strong&gt;OS:&lt;/strong&gt;&amp;nbsp;WIN 10 Pro 64-bit&lt;/span&gt;&lt;/p&gt;&lt;p&gt;&lt;span style=&quot;color: rgb(98, 98, 98); font-family: &amp;quot;Open Sans&amp;quot;, Arial, Tahoma, sans-serif;&quot;&gt;Microtower, 300W&lt;/span&gt;&lt;/p&gt;&lt;p&gt;&lt;span style=&quot;color: rgb(98, 98, 98); font-family: &amp;quot;Open Sans&amp;quot;, Arial, Tahoma, sans-serif;&quot;&gt;USB Opt?ki mi&scaron;, USB tastatura&lt;/span&gt;&lt;/p&gt;&lt;p&gt;&lt;span style=&quot;color: rgb(98, 98, 98); font-family: &amp;quot;Open Sans&amp;quot;, Arial, Tahoma, sans-serif;&quot;&gt;Garancija: 1 godina&lt;/span&gt;&lt;/p&gt;","3","6203-31576-1201.jpg");


--
-- Tabel structure for table `tax_list`
--
DROP TABLE  IF EXISTS `tax_list`;
CREATE TABLE `tax_list` (
  `tax_id` int(10) NOT NULL AUTO_INCREMENT,
  `tax_name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tax_amount` int(10) NOT NULL,
  PRIMARY KEY (`tax_id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `tax_list`  VALUES ( "1","PDV","17");
INSERT INTO `tax_list`  VALUES ( "2","Charity Tax","1");
INSERT INTO `tax_list`  VALUES ( "3","International Bill Tax","2");


--
-- Tabel structure for table `userimage`
--
DROP TABLE  IF EXISTS `userimage`;
CREATE TABLE `userimage` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `url` text COLLATE utf8mb4_unicode_ci,
  `lastUpload` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user` (`user`),
  CONSTRAINT `userimage_ibfk_1` FOREIGN KEY (`user`) REFERENCES `users` (`username`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `userimage`  VALUES ( "1","venan@admin.com","venan@admin.com.png","2017-12-27 16:40:08");
INSERT INTO `userimage`  VALUES ( "2","samed@user.com","Samed.jpg","2017-11-27 20:28:16");
INSERT INTO `userimage`  VALUES ( "3","demo@demo.com","","");


--
-- Tabel structure for table `users`
--
DROP TABLE  IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `username` varchar(35) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `firstname` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lastname` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role` int(12) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `users`  VALUES ( "1","venan@admin.com","$2y$10$4fzd88PicnuunKOb/S8jNuFEiWrMQ5sfi028KoGx1.hcOmX9RZblO","Venan","Osmic","1");
INSERT INTO `users`  VALUES ( "2","samed@user.com","$2y$10$rWAwhk/tTvAo2V1TmApg9u5fTkHHcWYLZekXSI.hrofRLH0r7sUV2","Samed","Juki?","0");
INSERT INTO `users`  VALUES ( "3","demo@demo.com","$2y$10$3Po24LNoCC.2BJlFfh.MUeEfLvEGO/kSFVjIrHCGET14Du3Tr4JV6","Demo","Demo","0");


SET FOREIGN_KEY_CHECKS = 1 ; 
COMMIT ; 
SET AUTOCOMMIT = 1 ; 
